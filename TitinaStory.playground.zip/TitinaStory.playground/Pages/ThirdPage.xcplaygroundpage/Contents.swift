//: [Previous](@previous)

import UIKit
import SwiftUI
import PlaygroundSupport
import Foundation

struct ContentView: View {
    @State var opacityText = 0.0
    @State var opacityNaples = 0.0
    @State var opacityTitina = 0.0
    @State var opacityTobacconist = 0.0
    @State var opacityPoliceCar = 0.0
    @State var opacityLeftLamp = 0.0
    @State var opacityRightLamp = 0.0
    @State var opacityCrush = 0.0
    @State var opacityRoad = 0.0
    @State var scale: CGFloat = 1;
    @State var xTobacconist = -400.0
    @State var xPoliceCar = -720.0
    @State var yText = 180.0
    
    
    var body: some View {
        
        ZStack {
            
            Image(uiImage: UIImage(named: "Background.jpg")!)
                .resizable()
                .scaledToFit()
                .frame(width: 1300, height: 1550)
                .opacity(1)
                .scaleEffect(scale)
            
            Image(uiImage: UIImage(named: "Naples.png")!)
                .resizable()
                .opacity(opacityNaples)
                .frame(width: 400, height: 450, alignment: .top)
                .offset(x: 0, y: -150)
            
            Image(uiImage: UIImage(named: "Road.png")!)
                .resizable()
                .opacity(opacityRoad)
                .frame(width: 500, height: 100)
                .offset(x: -50, y: 15)
            
            Image(uiImage: UIImage(named: "Lamp.png")!)
                .resizable()
                .opacity(opacityLeftLamp)
                .frame(width: 100, height: 150)
                .offset(x: -120, y: -60)
            
            Image(uiImage: UIImage(named: "Lamp.png")!)
                .resizable()
                .opacity(opacityRightLamp)
                .frame(width: 100, height: 150)
                .offset(x: 120, y: -60)
            
            Image(uiImage: UIImage(named: "Tobacconist.png")!)
                .resizable()
                .opacity(opacityTobacconist)
                .frame(width: 150, height: 150)
                .offset(x: xTobacconist, y: 0)
            
            Image(uiImage: UIImage(named: "PoliceCar.png")!)
                .resizable()
                .opacity(opacityPoliceCar)
                .frame(width: 200, height: 200)
                .offset(x: xPoliceCar, y: 15)
            
            Text("Andrea having understood the situation, told her that he had to go and 'buy cigarettes' and ran off with the ticket. Titina, immediately notifies the competent authorities to recover her money, but Andrea is not found. Nobody knows where he is, so Titina had already given up on the idea of having lost her prize.")
                .opacity(opacityText)
                .frame(width: 380, height: 160)
            
                .offset(x: 0, y: yText)
            
                .onAppear{
                    
                    let baseAnimation = Animation.easeIn(duration: 1)
                    let repeated = baseAnimation.repeatCount(1)
                    withAnimation(repeated) {
                        scale = 0.5
                    }
                    
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            while opacityNaples < 1 {
                                withAnimation(repeated) {
                                    opacityNaples = opacityNaples + 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                            while opacityRoad < 1 {
                                withAnimation(repeated) {
                                    opacityRoad = opacityRoad + 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
                            while opacityLeftLamp < 1 {
                                withAnimation(repeated) {
                                    opacityLeftLamp = opacityLeftLamp + 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
                            while opacityRightLamp < 1 {
                                withAnimation(repeated) {
                                    opacityRightLamp = opacityRightLamp + 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            while opacityTobacconist < 1 {
                                withAnimation(repeated) {
                                    opacityTobacconist = opacityTobacconist + 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            while opacityPoliceCar < 1 {
                                withAnimation(repeated) {
                                    opacityPoliceCar = opacityPoliceCar + 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
                            while opacityText < 1 {
                                withAnimation(repeated) {
                                    opacityText = opacityText + 0.1
                                }
                            }
                        }
                    }
                    
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
                            while opacityNaples > 0 {
                                withAnimation(repeated) {
                                    opacityNaples = opacityNaples - 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
                            while opacityRoad > 0 {
                                withAnimation(repeated) {
                                    opacityRoad = opacityRoad - 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
                            while opacityLeftLamp > 0{
                                withAnimation(repeated) {
                                    opacityLeftLamp = opacityLeftLamp - 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
                            while opacityRightLamp > 0{
                                withAnimation(repeated) {
                                    opacityRightLamp = opacityRightLamp - 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
                            while opacityTobacconist > 0 {
                                withAnimation(repeated) {
                                    opacityTobacconist = opacityTobacconist - 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
                            while opacityPoliceCar > 0 {
                                withAnimation(repeated) {
                                    opacityPoliceCar = opacityPoliceCar - 0.1
                                }
                            }
                        }
                    }
                    
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
                            while yText > 0 {
                                withAnimation(repeated) {
                                    yText = yText - 10.0
                                }
                            }
                        }
                    }
                    
                    withAnimation(Animation.linear(duration: 15)) {
                        DispatchQueue.main.asyncAfter(deadline: .now () + 4) {
                            while xTobacconist < 25 {
                                withAnimation(repeated) {
                                    xTobacconist = xTobacconist + 25.0
                                    xPoliceCar = xPoliceCar + 25.0
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                                    while xTobacconist < 800{
                                        withAnimation(repeated) {
                                            xTobacconist = xTobacconist + 25.0
                                            xPoliceCar = xPoliceCar + 25.0
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
        }.frame(width: 400, height: 600)
    }
}
PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
