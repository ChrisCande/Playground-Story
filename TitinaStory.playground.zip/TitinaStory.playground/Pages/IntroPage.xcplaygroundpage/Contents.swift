//: [Previous](@previous)

import UIKit
import SwiftUI
import PlaygroundSupport
import Foundation

struct ContentView: View {
    @State var scale: CGFloat = 3
    @State var opacityVarIntro = 1.0
    @State var opacityStoryIn = 0.0
    @State var opacityText = 0.0
    @State var opacityTitina = 0.0
    @State var opacityCartoon = 0.0
    @State var wMiniLogo = 1000.0
    @State var hMiniLogo = 1000.0
    @State var yRect = -700.0
    @State var yMiniLogo = -700.0
    
    public var body: some View {
        
        ZStack {
            Image(uiImage: UIImage(named: "TeamLogo.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 600, height: 600)
                .opacity(opacityVarIntro)
                .padding()
                .scaleEffect(scale)
            
            Rectangle()
                .fill(Color.gray)
                .frame(width: 280, height: 2)
                .opacity(opacityVarIntro)
                .offset(x: 10, y: yRect)
                .scaleEffect(scale)
                .padding()
            
            Image(uiImage: UIImage(named: "MiniLogo.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: wMiniLogo, height: hMiniLogo)
                .opacity(opacityVarIntro)
                .offset(x: 10, y: yMiniLogo)
                .scaleEffect(scale)
                .padding()
            
            Image(uiImage: UIImage(named: "StoryWallpaper.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 1300, height: 1550)
                .opacity(opacityStoryIn)
                .scaleEffect(scale)
            
            Image(uiImage: UIImage(named: "Titina.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 600, height: 600)
                .offset(x: -220, y: 120)
                .opacity(opacityTitina)
                .scaleEffect(scale)
            
            Image(uiImage: UIImage(named: "Cartoon.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 600, height: 600)
                .offset(x: 150, y: -200)
                .opacity(opacityCartoon)
                .scaleEffect(scale)
            
            
            Text("HI ! I'M TITINA, \nPROCEED \nTO KNOW MY STORY")
                .opacity(opacityText)
                .offset(x: 70, y: -110)
                .frame(width: 400, height: 600)
                .foregroundColor(.black)
                .font(.system(size: 15, weight: .bold, design: .serif))
            
                .onAppear {
                    let baseAnimation = Animation.easeIn(duration: 1)
                    let repeated = baseAnimation.repeatCount(1)
                    withAnimation(repeated) {
                        scale = 0.5
                    }
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            while opacityVarIntro > 0 {
                                withAnimation(repeated) {
                                    opacityVarIntro = opacityVarIntro - 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 2)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            while opacityStoryIn < 1 {
                                withAnimation(repeated) {
                                    opacityStoryIn = opacityStoryIn + 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 4)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                            while opacityText < 1 {
                                withAnimation(repeated) {
                                    opacityText = opacityText + 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 4)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                            while opacityTitina < 1 {
                                withAnimation(repeated) {
                                    opacityTitina = opacityTitina + 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 4)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                            while opacityCartoon < 1 {
                                withAnimation(repeated) {
                                    opacityCartoon = opacityCartoon + 0.1
                                }
                            }
                        }
                    }
                    withAnimation(Animation.linear(duration: 4)) {
                        while yRect < 1 {
                            withAnimation(repeated) {
                                yRect = yRect + 1.0
                                yMiniLogo = yMiniLogo + 1.0
                            }
                            if yRect <= 1{
                                while yRect < 100 {
                                    withAnimation(repeated) {
                                        yRect = yRect + 1.0
                                    }
                                }
                            }
                            if yMiniLogo <= 1{
                                while yMiniLogo < 150{
                                    withAnimation(repeated){
                                        yMiniLogo = yMiniLogo + 1.0
                                    }
                                }
                            }
                        }
                    }
                }
        }.frame(width: 400, height: 600)
    }
}
PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
