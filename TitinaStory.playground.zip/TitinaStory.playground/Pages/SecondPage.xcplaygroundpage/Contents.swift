//: [Previous](@previous)

import UIKit
import SwiftUI
import PlaygroundSupport
import Foundation

struct ContentView: View {
    
    @State var scale: CGFloat = 1;
    
    @State var opacityTobaccoShop = 0.0
    @State var opacityTitina = 0.0
    @State var opacityText1 = 0.0
    @State var opacityText2 = 0.0
    @State var opacityText3 = 0.0
    @State var opacityText4 = 0.0
    @State var opacitySAW = 0.0
    @State var opacityEuro = 0.0
    @State var opacityLeftPlusSymbol = 0.0
    @State var opacityRightPlusSymbol = 0.0
    @State var opacityBigWin = 0.0
    
    @State var TitinaWH = 80.0
    @State var ScratchAndWinWH = 10.0
    
    @State var xTitina = -20.0
    @State var xSAW = -20.0
    @State var xTobaccoShop = -120.0
    
    @State var yBigWin = -200.0
    @State var yTobaccoShop = 0.0
    
    public var body: some View {
        
        ZStack{
            
            Image(uiImage: UIImage(named: "Background.jpg")!)
                .resizable()
                .scaledToFit()
                .frame(width: 1300, height: 1550)
                .opacity(1)
            
            Image(uiImage: UIImage(named: "TobaccoShop.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 400, height: 400)
                .offset(x: xTobaccoShop, y: yTobaccoShop)
                .opacity(opacityTobaccoShop)
                .scaleEffect(scale)
            
            Image(uiImage: UIImage(named: "Titina.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: TitinaWH, height: TitinaWH)
                .offset(x: xTitina, y: 15)
                .opacity(opacityTitina)
            
            Image(uiImage: UIImage(named: "ScratchAndWin.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: ScratchAndWinWH, height: ScratchAndWinWH)
                .offset(x: xSAW, y: 15)
                .opacity(opacitySAW)
            
            Image(uiImage: UIImage(named: "TwoEuro.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 50, height: 50)
                .offset(x: 10, y: 0)
                .opacity(opacityEuro)
            
            Image(uiImage: UIImage(named: "PlusSymbol.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 30, height: 30)
                .offset(x: 70, y: 0)
                .opacity(opacityRightPlusSymbol)
            
            Image(uiImage: UIImage(named: "PlusSymbol.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 30, height: 30)
                .offset(x: -50, y: 0)
                .opacity(opacityLeftPlusSymbol)
            
            Image(uiImage: UIImage(named: "BigWin.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 150, height: 150)
                .offset(x: 0, y: yBigWin)
                .opacity(opacityBigWin)
            
            Group{
                
                Text("One day she decided to try her luck for the umpteenth time by buying a €5 scratch card in a tobacco shop in Materdei. The owner of this tobacconist, Andrea, in his forties, escapes Titina's gaze and chooses a scratch card from the box in the store.")
                
                    .opacity(opacityText1)
                    .frame(width: 380, height: 160)
                    .font(.system(size: 15, weight: .bold, design: .serif))
                    .offset(x: 0, y: -230)
                
                Text("Without much care Titina, once she has the ticket in her hands, starts scratching, as usual, with her lucky €2. And off goes a number, then another, then another. ")
                
                    .opacity(opacityText2)
                    .frame(width: 380, height: 160)
                    .font(.system(size: 15, weight: .bold, design: .serif))
                    .offset(x: 0, y: 230)
                
                Text("Unbelievably, at the sixth number she discovered, Titina saw the fgure of 500,000 euro on one of her numbers")
                
                    .opacity(opacityText3)
                    .frame(width: 380, height: 160)
                    .font(.system(size: 15, weight: .bold, design: .serif))
                    .offset(x: 0, y: 230)
                
                Text("Incredulous, she asked Andrea to check the ticket and certify the win")
                
                    .opacity(opacityText4)
                    .frame(width: 380, height: 160)
                    .font(.system(size: 15, weight: .bold, design: .serif))
                    .offset(x: 0, y: -230)
                
            }
            .onAppear{
                
                xSAW = xTitina + 20
                
                let baseAnimation = Animation.easeIn(duration: 1)
                let repeated = baseAnimation.repeatCount(1)
                withAnimation(repeated) {
                    scale = 0.5
                }
                
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        while opacityTobaccoShop < 1 {
                            withAnimation(repeated) {
                                opacityTobaccoShop = opacityTobaccoShop + 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        while opacityText1 < 1 {
                            withAnimation(repeated) {
                                opacityText1 = opacityText1 + 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 12) {
                        while opacityTitina < 1 {
                            withAnimation(repeated) {
                                opacityTitina = opacityTitina + 0.1
                                opacitySAW = opacitySAW + 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 20) {
                        while opacityEuro < 1 {
                            withAnimation(repeated) {
                                opacityEuro = opacityEuro + 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 20) {
                        while opacityLeftPlusSymbol < 1 {
                            withAnimation(repeated) {
                                opacityLeftPlusSymbol = opacityLeftPlusSymbol + 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 20) {
                        while opacityRightPlusSymbol < 1 {
                            withAnimation(repeated) {
                                opacityRightPlusSymbol = opacityRightPlusSymbol + 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 21) {
                        while opacityText2 < 1 {
                            withAnimation(repeated) {
                                opacityText2 = opacityText2 + 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 31) {
                        while opacityBigWin < 1 {
                            withAnimation(repeated) {
                                opacityBigWin = opacityBigWin + 0.1
                                yTobaccoShop = 0.0
                                xTobaccoShop = 0.0
                            }
                        }
                    }
                }
                withAnimation(Animation.linear(duration: 3)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 29) {
                        while opacityText2 > 0 {
                            withAnimation(repeated) {
                                opacityText2 = opacityText2 - 0.1
                            }
                        }
                    }
                }
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 31) {
                        while opacityText3 < 1 {
                            withAnimation(repeated) {
                                opacityText3 = opacityText3 + 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 3)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 39) {
                        while opacityLeftPlusSymbol > 0 {
                            withAnimation(repeated) {
                                opacityLeftPlusSymbol = opacityLeftPlusSymbol - 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 3)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 39) {
                        while opacityRightPlusSymbol > 0 {
                            withAnimation(repeated) {
                                opacityRightPlusSymbol = opacityRightPlusSymbol - 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 3)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 39) {
                        while opacityEuro > 0 {
                            withAnimation(repeated) {
                                opacityEuro = opacityEuro - 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 3)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 39) {
                        while opacityText3 > 0 {
                            withAnimation(repeated) {
                                opacityText3 = opacityText3 - 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 3)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 39) {
                        while opacitySAW > 0 {
                            withAnimation(repeated) {
                                opacitySAW = opacitySAW - 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 3)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 39) {
                        while opacityTitina > 0 {
                            withAnimation(repeated) {
                                opacityTitina = opacityTitina - 0.1
                                
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 39) {
                        while opacityTobaccoShop < 1 {
                            withAnimation(repeated) {
                                opacityTobaccoShop = opacityTobaccoShop + 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 4)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 41){
                        while yBigWin <= 200 {
                            withAnimation(repeated) {
                                yBigWin = yBigWin + 10
                            }
                        }
                    }
                }
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 40.5) {
                        while opacityText4 < 1 {
                            withAnimation(repeated) {
                                opacityText4 = opacityText4 + 0.1
                            }
                        }
                    }
                }
                
                withAnimation(Animation.linear(duration: 4)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 15) {
                        while xTitina < 100 {
                            withAnimation(repeated) {
                                xTitina = xTitina + 25.0
                                xSAW = xSAW + 25.0
                            }
                            withAnimation(Animation.linear(duration: 3)) {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                    while opacityText1 > 0 {
                                        withAnimation(repeated) {
                                            opacityText1 = opacityText1 - 0.1
                                        }
                                    }
                                }
                            }
                            withAnimation(Animation.linear(duration: 3)) {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                    while opacityTobaccoShop > 0 {
                                        withAnimation(repeated) {
                                            opacityTobaccoShop = opacityTobaccoShop - 0.1
                                        }
                                    }
                                }
                            }
                            withAnimation(Animation.linear(duration: 4)) {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                    while xTitina > -100 {
                                        withAnimation(repeated) {
                                            xTitina = xTitina - 25.0
                                        }
                                    }
                                }
                            }
                            withAnimation(Animation.linear(duration: 2)) {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                    while TitinaWH < 200 {
                                        withAnimation(repeated) {
                                            TitinaWH = TitinaWH + 10
                                            ScratchAndWinWH = ScratchAndWinWH + 5
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }.frame(width: 400, height: 600)
    }
}
PlaygroundPage.current.setLiveView(ContentView())


//: [Next](@next)
