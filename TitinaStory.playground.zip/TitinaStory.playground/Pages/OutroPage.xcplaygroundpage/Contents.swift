//: [Previous](@previous)

import UIKit
import SwiftUI
import PlaygroundSupport
import Foundation

struct ContentView: View {
    @State var scale: CGFloat = 3
    @State var opacityVarIntro = 1.0
    @State var opacityStoryIn = 0.0
    @State var opacityText = 0.0
    @State var opacityTitina = 0.0
    @State var opacityCartoon = 0.0
    @State var wMiniLogo = 1000.0
    @State var hMiniLogo = 1000.0
    @State var xTobacconist = -680.00
    
    var TitinaImg:UIImageView!
    
    var body: some View {
        ZStack {
            
            Image(uiImage: UIImage(named: "StoryWallpaper.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 1300, height: 1550)
                .opacity(opacityStoryIn)
                .scaleEffect(scale)
            
            Image(uiImage: UIImage(named: "Tobacconist.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 600, height: 600)
                .offset(x: xTobacconist, y: 120)
                .opacity(opacityTitina)
                .scaleEffect(scale)
            
            Image(uiImage: UIImage(named: "Cartoon.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 600, height: 600)
                .offset(x: 170, y: -200)
                .opacity(opacityCartoon)
                .scaleEffect(scale)
            
            Button{
                opacityText = 0
                opacityTitina = 0
                opacityStoryIn = 0
                opacityCartoon = 0
                
            } label: {
                Text("IT WAS A PLEASURE\n SEE YOU SOON")
                    .opacity(opacityText)
                    .offset(x: 90, y: -110)
                    .frame(width: 400, height: 600)
                    .foregroundColor(.black)
                    .font(.system(size: 15, weight: .bold, design: .serif))
            }
            
            .onAppear {
                let baseAnimation = Animation.easeIn(duration: 1)
                let repeated = baseAnimation.repeatCount(1)
                withAnimation(repeated) {
                    scale = 0.5
                }
                withAnimation(Animation.linear(duration: 3)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        while opacityVarIntro > 0 {
                            withAnimation(repeated) {
                                opacityVarIntro = opacityVarIntro - 0.1
                            }
                        }
                    }
                }
                withAnimation(Animation.linear(duration: 2)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        while opacityStoryIn < 1 {
                            withAnimation(repeated) {
                                opacityStoryIn = opacityStoryIn + 0.1
                            }
                        }
                    }
                }
                withAnimation(Animation.linear(duration: 4)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                        while opacityText < 1 {
                            withAnimation(repeated) {
                                opacityText = opacityText + 0.1
                            }
                        }
                    }
                }
                withAnimation(Animation.linear(duration: 4)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        while opacityTitina < 1 {
                            withAnimation(repeated) {
                                opacityTitina = opacityTitina + 0.1
                            }
                        }
                    }
                }
                withAnimation(Animation.linear(duration: 4)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                        while opacityCartoon < 1 {
                            withAnimation(repeated) {
                                opacityCartoon = opacityCartoon + 0.1
                            }
                        }
                    }
                }
                withAnimation(Animation.linear(duration: 4)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                        while opacityCartoon < 1 {
                            withAnimation(repeated) {
                                opacityCartoon = opacityCartoon + 0.1
                            }
                        }
                    }
                }
                withAnimation(Animation.linear(duration: 4)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                        while xTobacconist < 25 {
                            withAnimation(repeated) {
                                xTobacconist = xTobacconist + 25.0
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                                while xTobacconist < 800{
                                    withAnimation(repeated) {
                                        xTobacconist = xTobacconist + 25.0
                                    }
                                }
                                while opacityCartoon > 0 {
                                    withAnimation(repeated) {
                                        opacityCartoon = opacityCartoon - 0.1
                                        opacityText = opacityText - 0.1
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }.frame(width: 400, height: 600)
    }
}
PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
