//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport

let backgroundGradient = LinearGradient(
    colors: [Color.blue, Color.white],
    startPoint: .top, endPoint: .bottom)

struct ContentView: View {
    @State var scale = 1.0
    @State var rotation = false
    @State var opacityVar = 1.0
    @State var xfin = -30.0
    @State var yfin = -30.0
    @State var titinaWidth = 75.0
    @State var titinaHeight = 75.0
    @State var opacityText = 0.0
    @State var scale1: CGFloat = 3
    @State var opacityText2 = 0.0
    
    var body: some View {
        VStack {
            
            Text("A few more days later, Titina had already surrendered to the idea of having lost her prize. Just then, her cell phone rang. The authorities had found Andrea at the airport, heading to Cuba to enjoy the money without disturbance. Once he was caught, the policemen brought back the much desired ticket to Titina, who, finally calm, collected her winnings...")
                .opacity(opacityText)
                .padding()
                .frame(width: 500, height: 500, alignment: .top)
                .offset(x: 10, y: 290)
                .scaleEffect(scale1)
                .font(.system(size: 30, weight: .bold, design: .serif))
            Button {
                scale = 2
                Animation.linear(duration: 2)
                opacityVar = 0
                xfin = -10
                yfin = -50
                titinaWidth = 150
                titinaHeight = 150
                opacityText = 0
                opacityText2 = 1
                
            } label: {
                Text("GET RICH!")
                    .padding(10)
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(10)
                    .opacity(opacityVar)
            }
            ZStack {
                Image(uiImage: UIImage(named: "Gaeta.png")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: titinaWidth, height: titinaHeight)
                    .offset(x: xfin, y: yfin)
                    .opacity(opacityText2)
                    .scaleEffect(scale)
                    .animation(.linear(duration: 2), value: scale
                    )
                    .offset(x: 25)
                
            }
            ZStack {
                Image(uiImage: UIImage(named: "Titina.png")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: titinaWidth, height: titinaHeight)
                    .offset(x: xfin, y: yfin)
                    .padding()
                    .opacity(opacityText2)
                    .scaleEffect(scale)
                    .animation(.linear(duration: 2), value: scale
                    )
                    .offset(x: 25)
                
                Text("So, a few months later, she bought the much desired house in Gaeta, to spend the rest of her life in the dream she had premeditated for years.")
                    .opacity(opacityText2)
                    .frame(width: 300, height: 100, alignment: .bottom)
                    .offset(x: 0.0, y: 45.0)
                    .font(.system(size: 15, weight: .bold, design: .serif))
                
            }
            Spacer()
            Image(uiImage: UIImage(named: "Telephone.png")!)
                .resizable()
                .scaledToFit()
                .clipShape(Circle())
                .background(Color .white)
                .clipShape(Circle())
                .overlay(Circle() .stroke(Color .gray, lineWidth: 5))
                .padding()
                .frame(width:300, height:300)
                .offset(x: 0, y: -275)
                .opacity(opacityVar)
                .onTapGesture {
                    rotation = true
                }
                .rotationEffect(rotation ? .zero : Angle.degrees(360))
                .animation(.linear(duration: 10).repeatCount(1), value: rotation)
        }.background(backgroundGradient)
        
            .onAppear{
                let baseAnimation = Animation.easeIn(duration: 1)
                let repeated = baseAnimation.repeatCount(1)
                
                withAnimation(repeated) {
                    scale1 = 0.5
                }
                withAnimation(Animation.linear(duration: 4)) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        opacityText = 1
                    }
                }
            }
            .frame(width: 400, height: 600)
    }
}

PlaygroundPage.current.setLiveView(ContentView())




//: [Next](@next)
