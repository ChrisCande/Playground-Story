//: [Previous](@previous)

import UIKit
import SwiftUI
import PlaygroundSupport
import AVFoundation


struct ContentView: View {
    
    @State var scale: CGFloat = 1;
    
    @State var opacityNaples = 0.0
    @State var opacityTitina = 0.0
    @State var opacityText = 0.0
    
    @State var yNaples = 0.0
    // Per import audio on page copy from line 16 to 34
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "audioPage1", withExtension: "mp3") {
            
            try! player = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
            player.numberOfLoops = -1 /// Number of times to loop the audio
            //self.audioPlayer?.play() /// start playing
            
            return player
            
        } else {
            print("No audio file found")
        }
        
        return nil
        
    }()
    
    var body: some View {
        
        
        ZStack {
            
            Image(uiImage: UIImage(named: "Background.jpg")!)
                .resizable()
                .scaledToFit()
                .frame(width: 1300, height: 1550)
                .opacity(1)
                .scaleEffect(scale)
            
            
            
            Image(uiImage: UIImage(named: "Titina.png")!)
                .resizable()
                .opacity(opacityTitina)
                .frame(width: 150, height: 150)
                .offset(x: -60, y: 15)
            
            Text("An unlucky lady, who has always lived in the shadow of her savings and with a gambling habit, has lived in Naples since the tender age of 10. Titina (this is the name of the lady) would like to move to Gaeta to spend the rest of her life by the sea and in the cool breeze of the Low Lazio coast.")
                .opacity(opacityText)
                .frame(width: 380, height: 160)
                .font(.system(size: 15, weight: .bold, design: .serif))
                .offset(x: 0, y: 230)
            
            Image(uiImage: UIImage(named: "NaplesCartoon.png")!)
                .resizable()
                .opacity(opacityNaples)
                .frame(width: 400, height: 600, alignment: .top)
                .offset(x: 0, y: yNaples)
            
                .onAppear {
                    
                    let baseAnimation = Animation.easeIn(duration: 1)
                    let repeated = baseAnimation.repeatCount(1)
                    withAnimation(repeated) {
                        scale = 0.5
                    }
                    
                    audioPlayer?.play()
                    
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            while opacityNaples < 1 {
                                withAnimation(repeated) {
                                    opacityNaples = opacityNaples + 0.1
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                    while yNaples > -150 {
                                        withAnimation(repeated) {
                                            yNaples = yNaples - 10.0
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    withAnimation(Animation.linear(duration: 3)) {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                            while opacityText < 1 {
                                withAnimation(repeated) {
                                    opacityText = opacityText + 0.1
                                }
                            }
                        }
                    }
                    
                }
        }.frame(width: 400, height: 600)
    }
}
PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
